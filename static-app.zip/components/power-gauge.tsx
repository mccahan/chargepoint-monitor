import { Progress } from "@/components/ui/progress"

interface PowerGaugeProps {
  label: string
  value: number
  maxValue: number
  unit: string
  color: "green" | "amber" | "blue" | "red"
}

export default function PowerGauge({ label, value, maxValue, unit, color }: PowerGaugeProps) {
  const percentage = Math.min(Math.round((value / maxValue) * 100), 100)
  const friendly = maxValue.toLocaleString()

  const getColorClass = () => {
    switch (color) {
      case "green":
        return "text-green-600"
      case "amber":
        return "text-amber-600"
      case "blue":
        return "text-blue-600"
      case "red":
        return "text-red-600"
      default:
        return "text-gray-600"
    }
  }

  const getProgressColor = () => {
    switch (color) {
      case "green":
        return "bg-green-600"
      case "amber":
        return "bg-amber-600"
      case "blue":
        return "bg-blue-600"
      case "red":
        return "bg-red-600"
      default:
        return "bg-gray-600"
    }
  }

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium">{label}</span>
        <span className={`text-sm font-bold ${getColorClass()}`}>
          {value.toLocaleString()} {unit}
        </span>
      </div>
      <Progress value={percentage} className="h-2" indicatorClassName={getProgressColor()} />
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>0 {unit}</span>
        <span>
          {friendly} {unit}
        </span>
      </div>
    </div>
  )
}

