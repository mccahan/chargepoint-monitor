import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Battery, BatteryCharging, Plug } from "lucide-react"
import type { ChargingData } from "@/components/dashboard"

interface StatusCardProps {
  data: ChargingData | null
}

export default function StatusCard({ data }: StatusCardProps) {
  const getStatusIcon = () => {
    switch (data?.charging_status) {
      case "CHARGING":
        return <BatteryCharging className="h-12 w-12 text-green-500" />
      case "PLUGGED_IN":
        return <Plug className="h-12 w-12 text-amber-500" />
      case "AVAILABLE":
        return <Battery className="h-12 w-12 text-blue-500" />
      default:
        return <Battery className="h-12 w-12 text-gray-400" />
    }
  }

  const getStatusColor = () => {
    switch (data?.charging_status) {
      case "CHARGING":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"
      case "PLUGGED_IN":
        return "bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100"
      case "AVAILABLE":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100"
    }
  }

  const getStatusDescription = () => {
    switch (data?.charging_status) {
      case "CHARGING":
        return "Your vehicle is currently charging"
      case "PLUGGED_IN":
        return "Vehicle connected but not charging"
      case "AVAILABLE":
        return "Charger is ready for connection"
      default:
        return "Status unknown"
    }
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Charging Status</CardTitle>
        <CardDescription>Current state of your EV charger</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center p-6 space-y-4">
          {getStatusIcon()}
          <div className={`px-4 py-2 rounded-full font-medium ${getStatusColor()}`}>
            {data?.charging_status.replace('_', ' ') || "UNKNOWN"}
          </div>
          <p className="text-center text-muted-foreground">{getStatusDescription()}</p>
          {data?.charging_status === "CHARGING" && (
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Currently charging at</p>
              <p className="text-3xl font-bold">{data.amperage_limit} A</p>
              <p className="">{(data.amperage_limit*240/1000).toFixed(1)} kW</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

