"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BatteryCharging, Zap } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import StatusCard from "@/components/status-card"
import PowerGauge from "@/components/power-gauge"
import ChargingControls from "@/components/charging-controls"
import { useWebSocket } from "@/lib/use-websocket"

export type ChargingData = {
  charging_status: "CHARGING" | "AVAILABLE" | "PLUGGED_IN"
  amperage_limit: number
  excess: number
  minimum_overhead: number
  total_solar: number
}

// Sample data for initial state and fallback
const sampleData: ChargingData = {
  charging_status: "AVAILABLE",
  amperage_limit: 32,
  excess: 1500,
  minimum_overhead: 240,
  total_solar: 3000,
}

export default function Dashboard() {
  // Initialize with sample data
  const [initialData, setInitialData] = useState<ChargingData>(sampleData)
  const { data, isConnected, lastMessage, sendMessage } = useWebSocket<ChargingData>("http://localhost:8085/ws")
  const { toast } = useToast()

  // Use the actual data if available, otherwise use the initial sample data
  const displayData = data || initialData

  useEffect(() => {
    if (!isConnected) {
      toast({
        title: "Connection lost",
        description: "Attempting to reconnect to the charging system...",
        variant: "destructive",
      })
    }
  }, [isConnected, toast])

  return (
    <div className="container mx-auto p-4 space-y-6">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 py-6">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <BatteryCharging className="h-8 w-8 text-green-500" />
            Solar Charge Monitor
          </h1>
          <p className="text-muted-foreground">Optimize your EV charging with excess solar power</p>
        </div>
        <div className="flex items-center gap-2">
          <div className={`h-3 w-3 rounded-full ${isConnected ? "bg-green-500" : "bg-red-500"} animate-pulse`}></div>
          <span className="text-sm font-medium">{isConnected ? "Connected" : "Disconnecting..."}</span>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatusCard data={displayData} />

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-amber-500" />
              Current Power
            </CardTitle>
            <CardDescription>Real-time power metrics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <PowerGauge label="Total Solar" value={displayData.total_solar} maxValue={6200} unit="W" color="amber" />
              <PowerGauge label="Excess Solar" value={displayData.excess} maxValue={6200} unit="W" color="green" />
              <PowerGauge
                label="Charging Power"
                value={displayData.amperage_limit * 240}
                maxValue={6200}
                unit="W"
                color="blue"
              />
            </div>
          </CardContent>
        </Card>

        <ChargingControls data={displayData} sendMessage={sendMessage} />
      </div>

      <Tabs defaultValue="realtime" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="realtime">Real-time Data</TabsTrigger>
        </TabsList>
        <TabsContent value="realtime" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Live Charging Data</CardTitle>
              <CardDescription>Current charging parameters and solar production</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Charging Status</h3>
                  <p className="text-2xl font-bold">{displayData.charging_status.replace("_", " ") || "Unknown"}</p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Amperage Limit</h3>
                  <p className="text-2xl font-bold">{displayData.amperage_limit} A</p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Excess Solar</h3>
                  <p className="text-2xl font-bold">{displayData.excess.toLocaleString()} W</p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Minimum Overhead</h3>
                  <p className="text-2xl font-bold">{displayData.minimum_overhead.toLocaleString()} W</p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Total Solar</h3>
                  <p className="text-2xl font-bold">{displayData.total_solar.toLocaleString()} W</p>
                </div>
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Last Updated</h3>
                  <p className="text-sm">{lastMessage ? new Date().toLocaleTimeString() : "Never"}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

