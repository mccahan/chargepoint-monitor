"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { Settings, Zap, Lock } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import type { ChargingData } from "@/components/dashboard"

interface ChargingControlsProps {
  data: ChargingData | null
  sendMessage: (message: string) => void
}

export default function ChargingControls({ data, sendMessage }: ChargingControlsProps) {
  const [autoAdjust, setAutoAdjust] = useState(true)
  const [manualAmps, setManualAmps] = useState(data?.amperage_limit || 32)
  const [minOverhead, setMinOverhead] = useState(data?.minimum_overhead || 240)

  const handleAmperageChange = (value: number[]) => {
    setManualAmps(value[0])
  }

  const handleOverheadChange = (value: number[]) => {
    setMinOverhead(value[0])
  }

  const applySettings = () => {
    const settings = {
      auto_adjust: autoAdjust,
      amperage_limit: autoAdjust ? null : manualAmps,
      minimum_overhead: minOverhead,
    }

    // Send settings to the WebSocket server
    sendMessage(JSON.stringify(settings))

    console.log("Applying settings:", settings)
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5 text-blue-500" />
          Charging Controls
        </CardTitle>
        <CardDescription>Adjust your charging parameters</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="auto-adjust">Auto Adjust Amperage</Label>
            <p className="text-xs text-muted-foreground">Automatically adjust based on solar excess</p>
          </div>
          <Switch id="auto-adjust" checked={autoAdjust} onCheckedChange={setAutoAdjust} />
        </div>

        <div className="space-y-4">
          <div>
            <Label htmlFor="amperage-slider" className="flex justify-between">
              <span className={autoAdjust ? "text-muted-foreground" : ""}>
                Maximum Amperage Limit {autoAdjust && <Lock className="inline-block w-3 h-3 ml-1" />}
              </span>
              <span className={`font-bold ${autoAdjust ? "text-muted-foreground" : ""}`}>{manualAmps} A</span>
            </Label>
            <Slider
              id="amperage-slider"
              disabled={autoAdjust}
              value={[manualAmps]}
              min={8}
              max={40}
              step={1}
              onValueChange={handleAmperageChange}
              className={`mt-2 ${autoAdjust ? "opacity-50" : ""}`}
            />
            <div
              className={`flex justify-between text-xs mt-1 ${autoAdjust ? "text-muted-foreground/50" : "text-muted-foreground"}`}
            >
              <span>6A</span>
              <span>40A</span>
            </div>
          </div>

          <div>
            <Label htmlFor="overhead-slider" className="flex justify-between">
              <span>Minimum Power Overhead</span>
              <span className="font-bold">{minOverhead.toLocaleString()} W</span>
            </Label>
            <Slider
              id="overhead-slider"
              value={[minOverhead]}
              min={0}
              max={5000}
              step={100}
              onValueChange={handleOverheadChange}
              className="mt-2"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>0 W</span>
              <span>5,000 W</span>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={applySettings} className="w-full">
          <Zap className="h-4 w-4 mr-2" />
          Apply Settings
        </Button>
      </CardFooter>
    </Card>
  )
}

