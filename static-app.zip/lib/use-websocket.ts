"use client"

import { useEffect, useRef, useState } from "react"

interface WebSocketHook<T> {
  data: T | null
  isConnected: boolean
  lastMessage: string | null
  sendMessage: (message: string) => void
}

export function useWebSocket<T>(url: string): WebSocketHook<T> {
  const [data, setData] = useState<T | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [lastMessage, setLastMessage] = useState<string | null>(null)
  const socketRef = useRef<WebSocket | null>(null)

  useEffect(() => {
    const connectWebSocket = () => {
      const socket = new WebSocket(url)
      socketRef.current = socket

      socket.onopen = () => {
        setIsConnected(true)
        console.log("WebSocket connected")
      }

      socket.onmessage = (event) => {
        setLastMessage(event.data)
        try {
          const parsedData = JSON.parse(event.data) as T
          setData(parsedData)
        } catch (error) {
          console.error("Failed to parse WebSocket message:", error)
        }
      }

      socket.onclose = () => {
        setIsConnected(false)
        console.log("WebSocket disconnected")
        // Attempt to reconnect after a delay
        setTimeout(() => {
          if (socketRef.current?.readyState === WebSocket.CLOSED) {
            connectWebSocket()
          }
        }, 3000)
      }

      socket.onerror = (error) => {
        console.error("WebSocket error:", error)
      }

      return () => {
        socket.close()
      }
    }

    return connectWebSocket()
  }, [url])

  const sendMessage = (message: string) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(message)
    }
  }

  return {
    data,
    isConnected,
    lastMessage,
    sendMessage,
  }
}

